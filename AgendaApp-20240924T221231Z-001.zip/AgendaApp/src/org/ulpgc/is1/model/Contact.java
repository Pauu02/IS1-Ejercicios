package org.ulpgc.is1.model;

abstract class Contact {

    private final String telephone;
    private final String email;

    public Contact(String telephone, String email) {
        this.telephone = telephone;
        this.email = email;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getEmail() {
        return email;
    }
}
