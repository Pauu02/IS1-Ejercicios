package org.ulpgc.is1.model;

public class Addres {
    private final String street;
    private final int number;
    private final int floor;
    private final String city;

    public Addres(String street, int number, int floor, String city) {
        this.street = street;
        this.number = number;
        this.floor = floor;
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public int getNumber() {
        return number;
    }

    public int getFloor() {
        return floor;
    }

    public String getCity() {
        return city;
    }
}
