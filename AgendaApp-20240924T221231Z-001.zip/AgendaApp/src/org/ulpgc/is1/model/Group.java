package org.ulpgc.is1.model;

public class Group {
    public Group() {
    }
}
